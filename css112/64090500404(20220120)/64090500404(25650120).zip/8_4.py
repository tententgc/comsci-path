from math import *
r,theta = map(float, input().split()) 
print(r*cos(theta) , r*sin(theta)) 

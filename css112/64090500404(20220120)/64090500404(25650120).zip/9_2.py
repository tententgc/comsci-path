a,b,c = [x for x in input().split()] 
n = int(c)
s = a+b
print(a+b+c+ s*n)
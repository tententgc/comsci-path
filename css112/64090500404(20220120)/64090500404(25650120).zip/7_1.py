h = int(input())*3600
m = int(input())*60
s = int(input())
print(h+m+s)

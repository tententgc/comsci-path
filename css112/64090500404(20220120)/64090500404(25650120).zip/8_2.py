v1 ,v2,v3 = [int(x) for x in input().split()]
u1 ,u2,u3 = [int(x) for x in input().split()]
print(v1*u1+v2*u2+v3*u3)
 
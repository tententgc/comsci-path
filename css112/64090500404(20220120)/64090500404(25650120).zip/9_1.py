a = [float(x) for x in input().split()]
print(sum(a)/5)
